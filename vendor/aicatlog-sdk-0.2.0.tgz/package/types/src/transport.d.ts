import { z } from 'zod';
import { type Context } from './types.ts';
export type TransportCommand = {
    description: string;
    args?: z.ZodObject<any>;
    schema: z.ZodObject<any>;
    output?: z.ZodType;
    readOnly?: boolean;
    run: (ctx: Context, input: any) => Promise<unknown>;
};
export declare function openApi(commands: Map<string, TransportCommand>): {
    openapi: string;
    info: {
        title: string;
        version: string;
    };
    paths: Record<string, any>;
};
export declare function fetchCommand(commands: Map<string, TransportCommand>, ctx: Context, request: Request): Promise<Response>;
