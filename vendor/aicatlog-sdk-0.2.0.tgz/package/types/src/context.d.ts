import { type ContextInspection, type ContextSection, type Resource } from './types.ts';
type Profile = Pick<ContextInspection, 'document_role' | 'context_format' | 'classification'>;
type Inspection = Pick<ContextInspection, 'title' | 'summary' | 'sections' | 'references' | 'diagnostics' | 'valid'>;
export declare function contextProfile(resource: Resource): Profile | undefined;
export declare function inspectContextSource(rawLines: string[], profile: Profile): Inspection;
export declare function selectContextSection(sections: ContextSection[], selector: string): ContextSection;
export {};
