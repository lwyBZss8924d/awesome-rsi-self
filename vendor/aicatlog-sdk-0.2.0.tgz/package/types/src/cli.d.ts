import { z } from 'zod';
import { type Context } from './types.ts';
export type Extension = {
    namespace: string;
    commands: Record<string, Definition>;
};
export type Aicatlog = {
    serve: (argv?: string[], io?: {
        stdout?: (text: string) => void;
        exit?: (code: number) => void;
    }) => Promise<void>;
    call: (name: string, input?: Record<string, unknown>) => Promise<unknown>;
    fetch: (request: Request) => Promise<Response>;
};
type Definition = {
    description: string;
    args?: z.ZodObject<any>;
    options?: z.ZodObject<any>;
    output?: z.ZodType;
    sourceWrite?: boolean;
    readOnly?: boolean;
    run: (ctx: Context, input: any) => Promise<unknown>;
};
export declare function createAicatlog(defaults?: Partial<Context>, extensions?: Extension[]): Aicatlog;
export {};
