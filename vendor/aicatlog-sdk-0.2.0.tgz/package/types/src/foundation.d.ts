import { type Context } from './types.ts';
export declare function bootstrap(ctx: Context, options: {
    repo: string;
    name?: string;
    profile?: string;
    adopt?: boolean;
}): Promise<{
    plan_path: string;
    schema_version: "aicatlog.plan.v1";
    id: string;
    created_at: string;
    purpose: string;
    roots: string[];
    operations: {
        action: "write" | "copy" | "link" | "remove";
        target: string;
        before: string | null;
        source?: string | undefined;
        content?: string | undefined;
        executable?: boolean | undefined;
        source_digest?: string | undefined;
        excludes?: string[] | undefined;
        git_root?: string | undefined;
        no_symlink_parents_under?: string | undefined;
        protected_paths?: string[] | undefined;
    }[];
    conflicts: string[];
    notes: string[];
    plan_sha256: string;
    registry_sha256?: string | undefined;
}>;
export declare function checkFoundation(repo: string): Promise<{
    ok: boolean;
    repo: string;
    files: number;
    modified_files: string[];
    issues: {
        path: string;
        code: string;
    }[];
}>;
