import { z } from 'zod';
export declare const scopeSchema: z.ZodObject<{
    id: z.ZodString;
    root: z.ZodString;
    kind: z.ZodDefault<z.ZodEnum<{
        skills: "skills";
        market: "market";
        documents: "documents";
        repo: "repo";
    }>>;
    content_index: z.ZodDefault<z.ZodBoolean>;
    hidden: z.ZodDefault<z.ZodBoolean>;
    excludes: z.ZodDefault<z.ZodArray<z.ZodString>>;
    no_require_git: z.ZodDefault<z.ZodBoolean>;
    max_file_bytes: z.ZodDefault<z.ZodNumber>;
    idle_seconds: z.ZodDefault<z.ZodNumber>;
    manifests: z.ZodDefault<z.ZodArray<z.ZodString>>;
    manifest_base: z.ZodDefault<z.ZodEnum<{
        root: "root";
        file: "file";
    }>>;
    linked_roots: z.ZodDefault<z.ZodArray<z.ZodString>>;
    discovery: z.ZodDefault<z.ZodEnum<{
        recursive: "recursive";
        manifest: "manifest";
    }>>;
}, z.core.$strip>;
export type Scope = z.infer<typeof scopeSchema>;
export declare const resolutionSchema: z.ZodObject<{
    requested_id: z.ZodString;
    canonical_id: z.ZodString;
    via: z.ZodLiteral<"alias">;
}, z.core.$strip>;
export declare const resourceSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    kind: z.ZodString;
    scope: z.ZodString;
    owner: z.ZodString;
    summary: z.ZodString;
    path: z.ZodOptional<z.ZodString>;
    when: z.ZodOptional<z.ZodString>;
    parent: z.ZodOptional<z.ZodString>;
    children: z.ZodDefault<z.ZodArray<z.ZodString>>;
    command: z.ZodOptional<z.ZodArray<z.ZodString>>;
    source: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    document_role: z.ZodOptional<z.ZodString>;
    context_format: z.ZodOptional<z.ZodString>;
    resolution: z.ZodOptional<z.ZodObject<{
        requested_id: z.ZodString;
        canonical_id: z.ZodString;
        via: z.ZodLiteral<"alias">;
    }, z.core.$strip>>;
    activation: z.ZodOptional<z.ZodString>;
    topics: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        begin: z.ZodString;
        end: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$loose>;
export type Resource = z.infer<typeof resourceSchema>;
export declare const registrationSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    source: z.ZodObject<{
        kind: z.ZodEnum<{
            local: "local";
            git: "git";
            cli: "cli";
        }>;
        uri: z.ZodString;
        entry: z.ZodOptional<z.ZodString>;
        revision: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    target: z.ZodOptional<z.ZodString>;
    owner: z.ZodDefault<z.ZodString>;
    state: z.ZodDefault<z.ZodEnum<{
        optional: "optional";
        active: "active";
        disabled: "disabled";
        archived: "archived";
    }>>;
    activation: z.ZodDefault<z.ZodEnum<{
        native: "native";
        explicit: "explicit";
        on_demand: "on_demand";
    }>>;
    clients: z.ZodDefault<z.ZodArray<z.ZodString>>;
    metadata: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strip>;
export type Registration = z.infer<typeof registrationSchema>;
export declare const registrySchema: z.ZodObject<{
    schema_version: z.ZodLiteral<"aicatlog.registry.v1">;
    scopes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        root: z.ZodString;
        kind: z.ZodDefault<z.ZodEnum<{
            skills: "skills";
            market: "market";
            documents: "documents";
            repo: "repo";
        }>>;
        content_index: z.ZodDefault<z.ZodBoolean>;
        hidden: z.ZodDefault<z.ZodBoolean>;
        excludes: z.ZodDefault<z.ZodArray<z.ZodString>>;
        no_require_git: z.ZodDefault<z.ZodBoolean>;
        max_file_bytes: z.ZodDefault<z.ZodNumber>;
        idle_seconds: z.ZodDefault<z.ZodNumber>;
        manifests: z.ZodDefault<z.ZodArray<z.ZodString>>;
        manifest_base: z.ZodDefault<z.ZodEnum<{
            root: "root";
            file: "file";
        }>>;
        linked_roots: z.ZodDefault<z.ZodArray<z.ZodString>>;
        discovery: z.ZodDefault<z.ZodEnum<{
            recursive: "recursive";
            manifest: "manifest";
        }>>;
    }, z.core.$strip>>;
    skills: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        source: z.ZodObject<{
            kind: z.ZodEnum<{
                local: "local";
                git: "git";
                cli: "cli";
            }>;
            uri: z.ZodString;
            entry: z.ZodOptional<z.ZodString>;
            revision: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        target: z.ZodOptional<z.ZodString>;
        owner: z.ZodDefault<z.ZodString>;
        state: z.ZodDefault<z.ZodEnum<{
            optional: "optional";
            active: "active";
            disabled: "disabled";
            archived: "archived";
        }>>;
        activation: z.ZodDefault<z.ZodEnum<{
            native: "native";
            explicit: "explicit";
            on_demand: "on_demand";
        }>>;
        clients: z.ZodDefault<z.ZodArray<z.ZodString>>;
        metadata: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strip>>>;
    clients: z.ZodDefault<z.ZodArray<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    project_clients: z.ZodDefault<z.ZodArray<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    normalization_rules: z.ZodDefault<z.ZodArray<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    resources: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        kind: z.ZodString;
        scope: z.ZodString;
        owner: z.ZodString;
        summary: z.ZodString;
        path: z.ZodOptional<z.ZodString>;
        when: z.ZodOptional<z.ZodString>;
        parent: z.ZodOptional<z.ZodString>;
        children: z.ZodDefault<z.ZodArray<z.ZodString>>;
        command: z.ZodOptional<z.ZodArray<z.ZodString>>;
        source: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        document_role: z.ZodOptional<z.ZodString>;
        context_format: z.ZodOptional<z.ZodString>;
        resolution: z.ZodOptional<z.ZodObject<{
            requested_id: z.ZodString;
            canonical_id: z.ZodString;
            via: z.ZodLiteral<"alias">;
        }, z.core.$strip>>;
        activation: z.ZodOptional<z.ZodString>;
        topics: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            begin: z.ZodString;
            end: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$loose>>>;
    settings: z.ZodDefault<z.ZodObject<{
        resource_aliases: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$loose>>;
    import_provenance: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strip>;
export type Registry = z.infer<typeof registrySchema>;
export type Context = {
    registryPath: string;
    stateRoot: string;
    cacheRoot: string;
    sessionId: string;
    tgrep?: string;
};
export type Diagnostic = {
    code: string;
    path?: string;
    message: string;
};
export type Catalog = {
    schema_version: 'aicatlog.catalog.v1';
    generated_at: string;
    registry_sha256: string;
    resources: Resource[];
    errors: Diagnostic[];
    source_stamps?: Record<string, string>;
};
export declare const diagnosticSchema: z.ZodObject<{
    code: z.ZodString;
    path: z.ZodOptional<z.ZodString>;
    message: z.ZodString;
}, z.core.$strip>;
export declare const listOutputSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        kind: z.ZodString;
        scope: z.ZodString;
        owner: z.ZodString;
        summary: z.ZodString;
        path: z.ZodOptional<z.ZodString>;
        when: z.ZodOptional<z.ZodString>;
        parent: z.ZodOptional<z.ZodString>;
        children: z.ZodDefault<z.ZodArray<z.ZodString>>;
        command: z.ZodOptional<z.ZodArray<z.ZodString>>;
        source: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        document_role: z.ZodOptional<z.ZodString>;
        context_format: z.ZodOptional<z.ZodString>;
        resolution: z.ZodOptional<z.ZodObject<{
            requested_id: z.ZodString;
            canonical_id: z.ZodString;
            via: z.ZodLiteral<"alias">;
        }, z.core.$strip>>;
        activation: z.ZodOptional<z.ZodString>;
        topics: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            begin: z.ZodString;
            end: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$loose>>;
    total: z.ZodNumber;
    next_cursor: z.ZodNullable<z.ZodNumber>;
    catalog_generated_at: z.ZodString;
    diagnostics: z.ZodArray<z.ZodObject<{
        code: z.ZodString;
        path: z.ZodOptional<z.ZodString>;
        message: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const sourceReadSchema: z.ZodObject<{
    path: z.ZodString;
    sha256: z.ZodString;
    start_line: z.ZodNumber;
    end_line: z.ZodNumber;
    current_read_at: z.ZodString;
}, z.core.$strip>;
export declare const readOutputSchema: z.ZodObject<{
    id: z.ZodString;
    resolution: z.ZodOptional<z.ZodObject<{
        requested_id: z.ZodString;
        canonical_id: z.ZodString;
        via: z.ZodLiteral<"alias">;
    }, z.core.$strip>>;
    source: z.ZodObject<{
        path: z.ZodString;
        sha256: z.ZodString;
        start_line: z.ZodNumber;
        end_line: z.ZodNumber;
        current_read_at: z.ZodString;
    }, z.core.$strip>;
    text: z.ZodString;
    next_line: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const contextSectionSchema: z.ZodObject<{
    selector: z.ZodString;
    slug: z.ZodString;
    label: z.ZodString;
    level: z.ZodNumber;
    start_line: z.ZodNumber;
    end_line: z.ZodNumber;
}, z.core.$strip>;
export type ContextSection = z.infer<typeof contextSectionSchema>;
export declare const contextInspectionSchema: z.ZodObject<{
    schema_version: z.ZodLiteral<"aicatlog.context.v1">;
    id: z.ZodString;
    resolution: z.ZodOptional<z.ZodObject<{
        requested_id: z.ZodString;
        canonical_id: z.ZodString;
        via: z.ZodLiteral<"alias">;
    }, z.core.$strip>>;
    document_role: z.ZodEnum<{
        context_index: "context_index";
        prompt_context: "prompt_context";
    }>;
    context_format: z.ZodEnum<{
        "llms-txt-v2": "llms-txt-v2";
        markdown: "markdown";
    }>;
    classification: z.ZodEnum<{
        declared: "declared";
        filename: "filename";
    }>;
    source: z.ZodObject<{
        path: z.ZodString;
        sha256: z.ZodString;
        start_line: z.ZodNumber;
        end_line: z.ZodNumber;
        current_read_at: z.ZodString;
    }, z.core.$strip>;
    title: z.ZodNullable<z.ZodString>;
    summary: z.ZodNullable<z.ZodString>;
    sections: z.ZodArray<z.ZodObject<{
        selector: z.ZodString;
        slug: z.ZodString;
        label: z.ZodString;
        level: z.ZodNumber;
        start_line: z.ZodNumber;
        end_line: z.ZodNumber;
    }, z.core.$strip>>;
    references: z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        target: z.ZodString;
        kind: z.ZodEnum<{
            uri: "uri";
            relative: "relative";
            absolute: "absolute";
            fragment: "fragment";
        }>;
        start_line: z.ZodNumber;
        end_line: z.ZodNumber;
    }, z.core.$strip>>;
    diagnostics: z.ZodArray<z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
        severity: z.ZodEnum<{
            error: "error";
            warning: "warning";
        }>;
        start_line: z.ZodNumber;
        end_line: z.ZodNumber;
    }, z.core.$strip>>;
    valid: z.ZodBoolean;
}, z.core.$strip>;
export type ContextInspection = z.infer<typeof contextInspectionSchema>;
export declare class AicatlogError extends Error {
    code: string;
    details?: unknown | undefined;
    retryable: boolean;
    constructor(code: string, message: string, details?: unknown | undefined, retryable?: boolean);
}
export declare const operationSchema: z.ZodObject<{
    action: z.ZodEnum<{
        write: "write";
        copy: "copy";
        link: "link";
        remove: "remove";
    }>;
    target: z.ZodString;
    source: z.ZodOptional<z.ZodString>;
    content: z.ZodOptional<z.ZodString>;
    executable: z.ZodOptional<z.ZodBoolean>;
    before: z.ZodNullable<z.ZodString>;
    source_digest: z.ZodOptional<z.ZodString>;
    excludes: z.ZodOptional<z.ZodArray<z.ZodString>>;
    git_root: z.ZodOptional<z.ZodString>;
    no_symlink_parents_under: z.ZodOptional<z.ZodString>;
    protected_paths: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export declare const planSchema: z.ZodObject<{
    schema_version: z.ZodLiteral<"aicatlog.plan.v1">;
    id: z.ZodString;
    created_at: z.ZodString;
    purpose: z.ZodString;
    roots: z.ZodArray<z.ZodString>;
    registry_sha256: z.ZodOptional<z.ZodString>;
    operations: z.ZodArray<z.ZodObject<{
        action: z.ZodEnum<{
            write: "write";
            copy: "copy";
            link: "link";
            remove: "remove";
        }>;
        target: z.ZodString;
        source: z.ZodOptional<z.ZodString>;
        content: z.ZodOptional<z.ZodString>;
        executable: z.ZodOptional<z.ZodBoolean>;
        before: z.ZodNullable<z.ZodString>;
        source_digest: z.ZodOptional<z.ZodString>;
        excludes: z.ZodOptional<z.ZodArray<z.ZodString>>;
        git_root: z.ZodOptional<z.ZodString>;
        no_symlink_parents_under: z.ZodOptional<z.ZodString>;
        protected_paths: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>>;
    conflicts: z.ZodDefault<z.ZodArray<z.ZodString>>;
    notes: z.ZodDefault<z.ZodArray<z.ZodString>>;
    plan_sha256: z.ZodString;
}, z.core.$strip>;
export type Plan = z.infer<typeof planSchema>;
export type Operation = z.infer<typeof operationSchema>;
