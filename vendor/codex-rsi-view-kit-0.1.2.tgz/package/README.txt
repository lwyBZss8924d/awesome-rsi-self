{"schema_version":"rsi.text.v1","id":"rsi-view-kit","kind":"package-guide"}

Pure offline projection package. No filesystem, command execution, network or state ownership.
Exports: viewSchema, renderDashboard(view), safeHref, DashboardView and entity schemas.

viewSchema uses schema_version=rsi.view.v1 and kind=pm|kb. Required scalar fields:
id, title, description, revision (string), generated_at. Required collections:
lanes [{id,label}], projects [{id,title,summary,status}], items.
Items require id, project_id, title, summary and status matching a lane.
Optional collections: notices, links, metrics, findings and sources. See src/schema.ts.

Every item project and source reference must exist in the same view. Status vocabulary
belongs to the producer; the view package does not accept or advance business state.
The renderer validates its input and embeds the exact normalized view as JSON in
script#rsi-view. HTML is fully offline, responsive, keyboard navigable and searchable.
Remote scripts, fetch, external fonts and untrusted raw HTML are never inserted.
Link schemes are limited to http/https/file or relative paths; unsafe links become text.

Build: bun install --frozen-lockfile; bun run typecheck; bun test; bun run pack.
Install the produced fixed-version tarball, never a cross-repository workspace path.
