import { type Registry, type Catalog, type Context, type Resource } from './types.ts';
export declare function loadRegistry(ctx: Context): Promise<Registry>;
export declare const registryDigest: (ctx: Context) => Promise<string>;
export declare const catalogPath: (ctx: Context) => string;
export declare function refreshCatalog(ctx: Context): Promise<Catalog>;
export declare function getCatalog(ctx: Context): Promise<Catalog>;
export declare function selectResource(ctx: Context, id: string): Promise<Resource>;
export declare function listResources(ctx: Context, options?: {
    query?: string;
    kind?: string;
    scope?: string;
    limit?: number;
    cursor?: number;
}): Promise<{
    items: {
        [x: string]: unknown;
        id: string;
        name: string;
        kind: string;
        scope: string;
        owner: string;
        summary: string;
        children: string[];
        path?: string | undefined;
        when?: string | undefined;
        parent?: string | undefined;
        command?: string[] | undefined;
        source?: Record<string, unknown> | undefined;
        document_role?: string | undefined;
        context_format?: string | undefined;
        resolution?: {
            requested_id: string;
            canonical_id: string;
            via: "alias";
        } | undefined;
        activation?: string | undefined;
        topics?: {
            id: string;
            begin: string;
            end: string;
        }[] | undefined;
    }[];
    total: number;
    next_cursor: number | null;
    catalog_generated_at: string;
    diagnostics: import("./types.ts").Diagnostic[];
}>;
export declare function inspectContext(ctx: Context, id: string): Promise<{
    summary: string | null;
    diagnostics: {
        code: string;
        message: string;
        severity: "error" | "warning";
        start_line: number;
        end_line: number;
    }[];
    title: string | null;
    sections: {
        selector: string;
        slug: string;
        label: string;
        level: number;
        start_line: number;
        end_line: number;
    }[];
    references: {
        label: string;
        target: string;
        kind: "uri" | "relative" | "absolute" | "fragment";
        start_line: number;
        end_line: number;
    }[];
    valid: boolean;
    source: {
        path: string;
        sha256: string;
        start_line: number;
        end_line: number;
        current_read_at: string;
    };
    document_role: "context_index" | "prompt_context";
    context_format: "llms-txt-v2" | "markdown";
    classification: "declared" | "filename";
    resolution?: {
        requested_id: string;
        canonical_id: string;
        via: "alias";
    } | undefined;
    schema_version: "aicatlog.context.v1";
    id: string;
}>;
export declare function readResource(ctx: Context, id: string, options?: {
    section?: string;
    line?: number;
    limit?: number;
}): Promise<{
    source: {
        path: string;
        sha256: string;
        start_line: number;
        end_line: number;
        current_read_at: string;
    };
    text: string;
    next_line: number | null;
    resolution?: {
        requested_id: string;
        canonical_id: string;
        via: "alias";
    } | undefined;
    id: string;
}>;
export declare function checkRegistry(ctx: Context): Promise<{
    ok: boolean;
    schema_version: "aicatlog.registry.v1";
    registrations: number;
    scopes: number;
    issues: {
        code: string;
        id: string;
    }[];
}>;
