import { type Context } from './types.ts';
type WorkerIdentity = {
    pid: number;
    child_pid: number;
    child_identity: string | null;
    token: string;
    root: string;
    tgrep: string;
    started_at: string;
};
export declare function indexStatus(ctx: Context, scopeId: string): Promise<{
    scope: string;
    running: boolean;
    worker: WorkerIdentity | null;
    index_path: string;
    managed: boolean;
    consistency: string;
    native: Record<string, unknown> | null;
    current_filesystem_guarantee: boolean;
}>;
export declare function indexStart(ctx: Context, scopeId: string): Promise<{
    scope: string;
    status: string;
    consistency: string;
    lease: string;
    native: Record<string, unknown>;
}>;
export declare function indexStop(ctx: Context, scopeId: string): Promise<{
    scope: string;
    status: string;
    session_id: string;
    process_stop: string;
}>;
export declare function refreshContent(ctx: Context, scopeId: string): Promise<{
    scope: string;
    status: string;
    consistency: string;
    result: Record<string, unknown>;
}>;
/** The worker owns its child process handle; callers never signal an arbitrary PID from a file. */
export declare function indexWorker(configPath: string): Promise<void>;
export declare function contentFind(ctx: Context, query: string, options: {
    scope: string;
    fresh?: boolean;
    regex?: boolean;
    limit?: number;
    cursor?: number;
}): Promise<{
    items: {
        resource_ids: string[];
        path: string;
        line: number | null;
        text: string;
    }[];
    total: number;
    next_cursor: number | null;
    backend: string;
    fallback_reason: string | null;
    consistency: string;
    current_filesystem_guarantee: boolean;
    indexed_no_match_is_current_absence: boolean;
    scope: string;
    index_state: Record<string, unknown> | null;
    queried_at: string;
}>;
export {};
