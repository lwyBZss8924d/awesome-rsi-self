/** Publish without overwriting a path created by another writer between checks. */
export declare function renameExclusive(source: string, target: string): void;
