import { type Context } from './types.ts';
export declare function skillsPlan(ctx: Context, action: string, input: {
    id?: string;
    source?: string;
    skill?: string;
    scope?: string;
    target?: string;
    client?: string;
}): Promise<{
    plan_path: string;
    schema_version: "aicatlog.plan.v1";
    id: string;
    created_at: string;
    purpose: string;
    roots: string[];
    operations: {
        action: "write" | "copy" | "link" | "remove";
        target: string;
        before: string | null;
        source?: string | undefined;
        content?: string | undefined;
        executable?: boolean | undefined;
        source_digest?: string | undefined;
        excludes?: string[] | undefined;
        git_root?: string | undefined;
        no_symlink_parents_under?: string | undefined;
        protected_paths?: string[] | undefined;
    }[];
    conflicts: string[];
    notes: string[];
    plan_sha256: string;
    registry_sha256?: string | undefined;
}>;
export declare function skillsStatus(ctx: Context): Promise<{
    items: {
        id: string;
        name: string;
        owner: string;
        state: "optional" | "active" | "disabled" | "archived";
        activation: "native" | "explicit" | "on_demand";
        target: string | null;
        observed: string;
    }[];
    issues: {
        id: string;
        name: string;
        owner: string;
        state: "optional" | "active" | "disabled" | "archived";
        activation: "native" | "explicit" | "on_demand";
        target: string | null;
        observed: string;
    }[];
    total: number;
}>;
