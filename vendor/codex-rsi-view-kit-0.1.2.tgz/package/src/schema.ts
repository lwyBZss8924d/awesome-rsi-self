import { z } from 'zod';

const key = z.string().min(1).max(200);
const text = z.string().max(20000);
export const linkSchema = z.object({ label: text, href: z.string().max(12000) }).strict();
export const projectSchema = z.object({ id: key, title: text, summary: text, status: key,
  next_action: text.nullable().default(null), links: z.array(linkSchema).default([]) }).strict();
export const itemSchema = z.object({ id: key, project_id: key, title: text, summary: text,
  status: key, phase: text.default(''), control: text.nullable().default(null),
  priority: z.number().int().default(100), depends_on: z.array(key).default([]),
  next_action: text.nullable().default(null), updated_at: text.nullable().default(null),
  evidence: z.array(linkSchema).default([]), source_refs: z.array(key).default([]),
  badges: z.array(text).default([]) }).strict();
export const findingSchema = z.object({ id: key, title: text, description: text,
  status: key, linked_tasks: z.array(key).default([]), source_refs: z.array(key).default([]) }).strict();
export const sourceSchema = z.object({ id: key, title: text, kind: text, status: key,
  href: z.string().max(12000).nullable().default(null), version: text.nullable().default(null),
  description: text.default('') }).strict();
export const viewSchema = z.object({ schema_version: z.literal('rsi.view.v1'),
  kind: z.enum(['pm', 'kb']), id: key, title: text, description: text,
  revision: z.string().min(1), generated_at: z.string().min(1),
  notices: z.array(text).default([]), links: z.array(linkSchema).default([]),
  metrics: z.array(z.object({ label: text, value: z.union([z.string(), z.number()]) }).strict()).default([]),
  lanes: z.array(z.object({ id: key, label: text }).strict()).min(1),
  projects: z.array(projectSchema), items: z.array(itemSchema),
  findings: z.array(findingSchema).default([]), sources: z.array(sourceSchema).default([]),
}).strict().superRefine((view, ctx) => {
  for (const collection of ['projects', 'items', 'findings', 'sources', 'lanes'] as const) {
    const ids = new Set<string>();
    view[collection].forEach((value, i) => {
      if (ids.has(value.id)) ctx.addIssue({code:'custom',path:[collection,i,'id'],message:'Duplicate view identity'});
      ids.add(value.id);
    });
  }
  const projects = new Set(view.projects.map(p => p.id));
  const lanes = new Set(view.lanes.map(p => p.id));
  const sources = new Set(view.sources.map(p => p.id));
  view.items.forEach((item,i) => {
    if (!projects.has(item.project_id)) ctx.addIssue({code:'custom',path:['items',i,'project_id'],message:'Unknown project'});
    if (!lanes.has(item.status)) ctx.addIssue({code:'custom',path:['items',i,'status'],message:'Unknown lane'});
    if(item.source_refs.some(id=>!sources.has(id))) ctx.addIssue({code:'custom',path:['items',i,'source_refs'],message:'Unknown source'});
  });
});
export type DashboardView = z.infer<typeof viewSchema>;
export type DashboardItem = z.infer<typeof itemSchema>;
